Just upload loan_calc.js and loan_style.css to your server, paste the code from source.txt into an html file on your server, and that's it!

Make sure you put these two lines in the <head> section of your html file though...

<script type="text/javascript" src="loan_calc.js"></script>
<link rel="stylesheet" type="text/css" href="loan_style.css" />

FYI- The style sheet was written for this doctype...

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

Thanks for downloading from us! Come back often: www.bmgadg.com