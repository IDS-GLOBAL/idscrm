jstz
====

Javascript function useful to detect the browser  timezone
