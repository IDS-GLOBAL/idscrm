Open the config.php file and enter the mysql database user id password and db name. 
Use the sql_dump_checkbox.txt file to create your table and to populate the records.
Keep all the files in one directory and open the checkbox.php file from any location accessed by your server path. 

Use the contact us page or forum at www.plus2net.com to discuss / suggest / bugs or to reach us. 